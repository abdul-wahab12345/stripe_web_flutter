var stripePublishableKey = 'pk_test_jrMY5KO18TTVrRzYzZyRbR0a00IpQkK4qs';

var secretKey='sk_test_TqX0Y9mcG2no0LKyG7lpuhmd00gcglhtbc';
